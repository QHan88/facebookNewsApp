package com.example.facebookappcompose.ViewModel

import com.example.facebookappcompose.model.Page
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class FeedViewModel(val repository : FeedRepository) : ViewModel() {

    private val _feed = MutableLiveData<Page>()
    val feed : LiveData<Page> = _feed

    fun getNews() {
        viewModelScope.launch {

            val result = repository.fetchAllNews()

            if (result.isSuccessful) {
                _feed.value = result.body()

            }
        }
    }
}