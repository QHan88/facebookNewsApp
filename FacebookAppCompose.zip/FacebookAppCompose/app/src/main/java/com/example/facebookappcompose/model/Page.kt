package com.example.facebookappcompose.model


data class Page(
    val page: Cards
)

data class Cards(
    val cards: List<Card>
)

data class Card(
    val card_type:String,
    val card: Content
)

data class Content(
    val value:String?,
    val attributes: Attributes?,
    val title: Title?,
    val description: Description?,
    val image: Image?
)

data class Size(
    val width: Int,
    val height: Int
)
data class Title(
    val value: String,
    val attributes: Attributes
)

data class Image(
    val url:String,
    val size: Size
)

data class Description(
    val value: String,
    val attributes: Attributes
)
data class Attributes(
    val text_color:String,
    val font:Font
)
data class Font(
    val size: Int
)




