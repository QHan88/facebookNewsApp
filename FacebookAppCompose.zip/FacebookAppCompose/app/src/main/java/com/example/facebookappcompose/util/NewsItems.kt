package com.example.facebookappcompose.util

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.ui.Modifier
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.core.graphics.createBitmap
import com.bumptech.glide.Glide
import com.example.facebookappcompose.model.Page
import dev.chrisbanes.accompanist.glide.GlideImage

@Composable
fun NewsCard(
    newsData : Page,
    onClick:()->Unit){

    Card(
        shape = MaterialTheme.shapes.small,
        modifier = Modifier
            .padding(
                bottom = 6.dp,
                top = 6.dp
            )
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = 8.dp,
    )
    {
        Column{
            newsData.page.cards[0].card.image ?. let{ url ->

                Image(

                    createBitmap(
                        newsData.page.cards[0].card.image?.url?.let { GlideImage(data = it) },
                    ),
                    modifier = Modifier
                        .padding(
                            bottom = 6.dp,
                            top = 6.dp
                        )
                        .fillMaxWidth(),
                    contentScale = ContentScale.Fit,

                )
            }
            newsData.page.cards[0].card.title ?. let { title ->
                Row(
                    modifier = Modifier
                        .padding(
                            bottom = 12.dp,
                            top = 12.dp,
                            start = 8.dp,
                            end = 8.dp
                        )
                        .fillMaxHeight(),
                ) {
                  Text(
                      text = newsData.page.cards[0].card.title?.value.toString(),
                      modifier = Modifier
                          .fillMaxHeight()
                          .wrapContentHeight(Alignment.Top),
                      )
                }
            }
        }
    }
}