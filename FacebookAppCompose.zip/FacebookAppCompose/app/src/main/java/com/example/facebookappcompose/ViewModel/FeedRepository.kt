package com.example.facebookappcompose.ViewModel


import com.example.facebookappcompose.model.Page
import com.example.facebookappcompose.network.retrofitInstance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class FeedRepository constructor() {


    suspend fun fetchAllNews() : Response<Page> {

        return withContext(Dispatchers.IO){
            retrofitInstance.api.fetchAllNews()
        }
    }
}