package com.example.facebookappcompose.network

import com.example.facebookappcompose.model.Page

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @POST("test/home")
    suspend fun fetchAllNews(): Response<Page>
}