package com.example.facebookappcompose.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object retrofitInstance {

    val retrofit = Retrofit.Builder()
        .baseUrl("https://private-8ce77c-tmobiletest.apiary-mock.com")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api = retrofit.create(ApiService::class.java)
}