package com.example.facebookappcompose

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.facebookappcompose.ViewModel.FeedViewModel
import com.example.facebookappcompose.model.Page
import com.example.facebookappcompose.ui.theme.FacebookAppComposeTheme
import com.example.facebookappcompose.util.NewsCard

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FacebookAppComposeTheme {
                val feedViewModel:FeedViewModel = FeedViewModel()
                val newsList = feedViewModel.getNews()
                SetNewsList(newsList = newsList, this)
            }
        }
    }
}

@Composable
fun SetNewsList(newsList: List<Page>, c:Context) {
    LazyColumn {
        itemsIndexed(items = newsList){ index, NewsItem ->
            NewsCard(newsData = NewsItem, onClick = {
                Toast.makeText(c, NewsItem.page.cards.size,Toast.LENGTH_SHORT).show()
            })
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    FacebookAppComposeTheme {

    }
}